class ControlPlaneSDK {
  constructor(config = {}) {
    this.controlPlaneUrl = config.controlPlaneUrl || 'https://api.neuralcontrol.online';
    this.serviceName     = config.serviceName     || 'unknown-service';
    this.tenantId        = config.tenantId        || null;
    this.apiKey          = config.apiKey          || null;

    // ── Local config cache (the key to zero-latency decisions) ──────────────
    // Structure: { [endpoint]: { cache_enabled, circuit_breaker, ... , fetchedAt } }
    this._configCache    = {};
    this._configTTL      = config.configTTL   || 30_000;   // re-sync every 30s
    this._configTimeout  = config.configTimeout || 2_000;  // give up fetching after 2s

    // ── Signal batching (1 HTTP call per flush, not per request) ────────────
    this._signalQueue    = [];
    this._flushInterval  = config.flushInterval || 5_000;  // flush every 5s
    this._maxQueueSize   = config.maxQueueSize  || 500;    // safety cap
    this._flushTimer     = null;
    this._syncTimers     = {};  // one refresh timer per endpoint

    // ── Local Sliding Window Tracker (For Rate Limiting Edge-Side) ──────────
    this._customerRateLimits = new Map();

    // ── Safe defaults returned when control plane is unreachable ────────────
    this._safeDefaults = {
      cache_enabled:        false,
      circuit_breaker:      false,
      rate_limited_customer: false,
      queue_deferral:       false,
      load_shedding:        false,
      reason:               'Control plane fetching — using safe defaults',
    };

    if (!this.apiKey) {
      console.warn('[ControlPlane] ⚠️  No API key provided. Requests will be unauthenticated.');
    }

    // Start the signal flush loop immediately
    this._startFlushLoop();

    // Periodically clean up old IPs from memory to prevent leaks
    this._memoryCleanupTimer = setInterval(() => {
        this._customerRateLimits.clear();
    }, 3600000); // Clear counter map every 1 hour

    console.log(`[ControlPlane] SDK initialized for service "${this.serviceName}"`);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC: initialize(endpoints)
  // Call once at app startup to pre-warm config for known endpoints.
  // ═══════════════════════════════════════════════════════════════════════════

  async initialize(endpoints = []) {
    if (endpoints.length === 0) {
      console.warn('[ControlPlane] initialize() called with no endpoints — nothing to pre-warm.');
      return;
    }

    console.log(`[ControlPlane] Pre-warming config for ${endpoints.length} endpoint(s)...`);

    await Promise.allSettled(
      endpoints.map(ep => this._syncConfig(ep))
    );

    // Start periodic background refresh for each endpoint
    for (const ep of endpoints) {
      this._startSyncLoop(ep);
    }

    console.log(`[ControlPlane] ✅ Config ready. Decisions will be made locally (0ms network overhead).`);
  }


  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC: getConfig(endpoint, priority, customer_identifier)
  // NOW: reads from local memory — NO HTTP call — takes < 0.1ms
  // ═══════════════════════════════════════════════════════════════════════════

  getConfig(endpoint, priority = 'medium', customer_identifier = null) {
    const cached = this._configCache[endpoint];

    if (cached) {
      // ✅ Cache hit — return immediately, zero network I/O
      return this._applyCustomerRules(cached, customer_identifier);
    }

    // ⚠️  Cache miss (first time seeing this endpoint) — fetch synchronously
    console.warn(`[ControlPlane] Cache miss for "${endpoint}" — fetching now (first request only)`);
    this._syncConfig(endpoint).then(() => {
      this._startSyncLoop(endpoint);
    });

    return this._safeDefaults;
  }


  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC: track(endpoint, latencyMs, status, priority, customer_identifier, action_taken)
  // NOW: queues signal locally — NO immediate HTTP call
  // ═══════════════════════════════════════════════════════════════════════════

  track(endpoint, latencyMs, status = 'success', priority = 'medium', customer_identifier = null, action_taken = 'none') {
    if (this._signalQueue.length >= this._maxQueueSize) {
      // Queue is full — drop oldest signal (ring buffer behavior)
      this._signalQueue.shift();
    }

    this._signalQueue.push({
      service_name:         this.serviceName,
      endpoint,
      latency_ms:           Math.round(latencyMs),
      status,
      tenant_id:            this.tenantId,
      priority,
      customer_identifier,
      action_taken, // Tells the backend if it was rate limited locally!
      recorded_at:          new Date().toISOString(),
    });
  }


  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC: middleware(endpoint, options)
  // Express middleware — adds < 0.1ms overhead
  // ═══════════════════════════════════════════════════════════════════════════

  middleware(endpoint, options = {}) {
    const sdk      = this;
    const priority = options.priority || 'medium';

    // Ensure this endpoint is being synced in the background
    if (!this._syncTimers[endpoint]) {
      this._syncConfig(endpoint).then(() => sdk._startSyncLoop(endpoint));
    }

    return (req, res, next) => {
      const startTime = Date.now();

      // Extract customer IP
      const customer_identifier =
        req.headers['x-forwarded-for']?.split(',')[0].trim() ||
        req.ip ||
        req.connection?.remoteAddress ||
        null;

      // ✅ Decision from local cache — zero network I/O
      const config = sdk.getConfig(endpoint, priority, customer_identifier);
      const isRateLimited = config.rate_limited_customer || false;

      // Attach everything to req for the route handler
      req.controlPlane = {
        config,
        isRateLimitedCustomer: isRateLimited,
        isLoadShedding:        config.load_shedding         || false,
        isQueueDeferral:       config.queue_deferral        || false,
        shouldCache:           config.cache_enabled         || false,
        shouldSkip:            config.circuit_breaker       || false,
        statusCode:            config.status_code           || 200,
        retryAfter:            config.retry_after           || 60,
        estimatedDelay:        config.estimated_delay       || 10,
        reason:                config.reason                || '',
        customer_identifier,
        priority,
      };

      // Queue signal after response — non-blocking
      res.on('finish', () => {
        const latency = Date.now() - startTime;
        const isTrafficManagement = [202, 429, 503].includes(res.statusCode);
        const status = (res.statusCode < 400 || isTrafficManagement) ? 'success' : 'error';
        const action = isRateLimited ? 'rate_limited' : 'none';
        
        sdk.track(endpoint, latency, status, priority, customer_identifier, action);
      });

      next();
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC: destroy()
  // Clean shutdown
  // ═══════════════════════════════════════════════════════════════════════════

  async destroy() {
    console.log('[ControlPlane] Shutting down — flushing remaining signals...');
    clearInterval(this._flushTimer);
    clearInterval(this._memoryCleanupTimer);
    for (const timer of Object.values(this._syncTimers)) {
      clearInterval(timer);
    }
    await this._flushSignals();
    console.log('[ControlPlane] ✅ Shutdown complete.');
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PRIVATE INTERNALS
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Apply per-customer overrides to cached config.
   * Runs locally in memory (zero latency!) using a Sliding Window Counter.
   */
  _applyCustomerRules(config, customer_identifier) {
    const clone = { ...config };
    
    // Check if the control plane rule returned a rate limit threshold (e.g. 50 RPM)
    const limitRpm = config.rate_limit_rule_rpm;
    
    // Run sliding window counter logic locally
    if (limitRpm && customer_identifier) {
       clone.rate_limited_customer = this._isCustomerRateLimited(customer_identifier, limitRpm);
       if (clone.rate_limited_customer) {
           clone.reason = 'Customer rate limited locally by edge SDK';
       }
    } else {
       clone.rate_limited_customer = false;
    }
    
    return clone;
  }

  _isCustomerRateLimited(customer_identifier, limit_rpm) {
    const now = Date.now();
    const currentMinuteStr = Math.floor(now / 60000).toString();
    const previousMinuteStr = (Math.floor(now / 60000) - 1).toString();
    
    // Get or initialize the tracker for this IP
    let tracker = this._customerRateLimits.get(customer_identifier);
    if (!tracker) {
      tracker = { currentMinute: currentMinuteStr, currentCount: 0, previousCount: 0 };
      this._customerRateLimits.set(customer_identifier, tracker);
    }

    // Slide the window forward if a new minute started
    if (tracker.currentMinute !== currentMinuteStr) {
      tracker.previousCount = tracker.currentMinute === previousMinuteStr ? tracker.currentCount : 0;
      tracker.currentMinute = currentMinuteStr;
      tracker.currentCount = 0;
    }

    // Add this new request to the current minute
    tracker.currentCount++;

    // Calculate the weighted sliding window score
    const secondsIntoMinute = new Date(now).getSeconds();
    const weightOfPreviousMinute = (60 - secondsIntoMinute) / 60;
    
    const estimatedRpm = Math.floor(
      (tracker.previousCount * weightOfPreviousMinute) + tracker.currentCount
    );

    return estimatedRpm > limit_rpm;
  }

  async _syncConfig(endpoint) {
    try {
      const url = this._buildConfigUrl(endpoint);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this._configTimeout);

      const response = await fetch(url, {
        method:  'GET',
        headers: this._buildHeaders(),
        signal:  controller.signal,
      });

      clearTimeout(timeoutId);

      if (response.status === 401) {
        console.error('[ControlPlane] ❌ Invalid API key — check your configuration');
        return;
      }

      if (!response.ok) return;

      const config = await response.json();

      this._configCache[endpoint] = {
        ...config,
        _fetchedAt: Date.now(),
      };

    } catch (error) {
      // Keep existing cache if available — stale config is better than no config
    }
  }

  _startSyncLoop(endpoint) {
    if (this._syncTimers[endpoint]) return;
    this._syncTimers[endpoint] = setInterval(() => {
      this._syncConfig(endpoint).catch(() => {});
    }, this._configTTL);
  }

  _startFlushLoop() {
    this._flushTimer = setInterval(() => {
      if (this._signalQueue.length > 0) {
        this._flushSignals().catch(() => {});
      }
    }, this._flushInterval);
  }

  async _flushSignals() {
    if (this._signalQueue.length === 0) return;

    // Drain the queue atomically
    const batch = this._signalQueue.splice(0, this._signalQueue.length);
    let requeued = false; // Prevent double-requeueing 

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3_000);

      try {
        const response = await fetch(`${this.controlPlaneUrl}/api/signals/batch`, {
          method:  'POST',
          headers: this._buildHeaders(),
          body:    JSON.stringify({ signals: batch }),
          signal:  controller.signal,
        });

        if (!response.ok && response.status !== 401) {
          console.warn(`[ControlPlane] Batch flush failed (${response.status}) — ${batch.length} signals re-queued`);
          this._signalQueue.unshift(...batch.slice(0, this._maxQueueSize - this._signalQueue.length));
          requeued = true;
        }
      } finally {
        clearTimeout(timeoutId);
      }

    } catch (error) {
      if (error.name !== 'AbortError' && !requeued) {
        this._signalQueue.unshift(...batch.slice(0, this._maxQueueSize - this._signalQueue.length));
      }
    }
  }

  _buildHeaders() {
    const headers = { 'Content-Type': 'application/json' };
    if (this.apiKey) headers['Authorization'] = `Bearer ${this.apiKey}`;
    return headers;
  }

  _buildConfigUrl(endpoint) {
    const params = new URLSearchParams();
    if (this.tenantId) params.append('tenant_id', this.tenantId);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return `${this.controlPlaneUrl}/api/config/${this.serviceName}${endpoint}${qs}`;
  }
}

export default ControlPlaneSDK;